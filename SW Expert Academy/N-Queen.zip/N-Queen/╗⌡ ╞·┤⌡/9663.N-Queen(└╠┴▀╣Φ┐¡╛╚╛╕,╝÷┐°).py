
# def checkQ(line,x,putqueen):
def checkQ(q1,q2):
    # 세로 위 체크, 대각선, 반대각선 체크
    return abs(q1[0] - q2[0]) == abs(q1[1] - q2[1])

def NQ(line,visit,putqueen):
    global cnt
    # print(putqueen)
    if line == N:
        cnt += 1
        return
    for j in range(N):
        if visit[j] == 0:
            queen = (line,j)
            # print(putqueen)
            res = False
            for pq in putqueen:
                res = checkQ(pq,queen)
                    # print(checkQ(line,j,putqueen))
                if res == True:
                    break
            if not res :
                visit[j] = 1
                NQ((line + 1), visit, putqueen + [(line, j)] )
                visit[j] = 0

N = int(input())
cnt = 0
NQ(0, [0] * N,[])
print(cnt)