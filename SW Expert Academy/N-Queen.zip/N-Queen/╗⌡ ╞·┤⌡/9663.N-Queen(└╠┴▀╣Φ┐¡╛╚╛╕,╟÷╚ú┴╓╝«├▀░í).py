# 퀸과 퀸이 서로를 잡을 수 있나 없나
def can_catch(queen1, queen2):
    # 가로나 세로로 놓인 부분은 이미 필터링이 되어 있기 때문에
    # 대각선으로 놓일 때만 고려하면 됨
    # 대각선으로 놓인 경우 x좌표 차이와 y좌표 차이의 절대값이 같다!!!
    return abs(queen1[0] - queen2[0]) == abs(queen1[1] - queen2[1])


# location은 y축, visit는 x축, queens는 앞에 놓인 queen의 좌표값을 모두 저장
def n_queen(location, visit, queens):
    global N, cnt
    if location == N:
        cnt += 1
        return
    for i in range(N):
        if visit[i] == 0:  # 여기서 x축을 필터링
            queen = [location, i]
            res = False
            # 놓여있는 모든 queen에 대해 새로 놓을 queen이 대각선상에서 겹치는지 아닌지 판별
            for qs in queens:
                res = can_catch(qs, queen)
                # True라면 차이가 같다는 이야기이므로 놓을 수 없음
                if res == True:
                    break
            # 모든 필터링에 통과할 경우
            if not res:
                visit[i] = 1
                n_queen(location + 1, visit, queens + [[location, i]])
                visit[i] = 0


N = int(input())
cnt = 0
n_queen(0, [0] * N, [])
print(cnt)