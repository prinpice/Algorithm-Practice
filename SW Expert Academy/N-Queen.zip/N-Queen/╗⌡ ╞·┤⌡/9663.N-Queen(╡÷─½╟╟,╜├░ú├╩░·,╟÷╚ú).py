dx = [1, 1, -1, -1]
dy = [1, -1, -1, 1]


def deepcopy(standard):
    global N
    temp = [[0] * N for _ in range(N)]
    for i in range(N):
        for j in range(N):
            temp[i][j] = standard[i][j]
    return temp


def n_queen(location, visited):
    global N, cnt
    if location == N:
        cnt += 1
        return
    for i in range(N):
        visit = deepcopy(visited)
        if visit[location][i] == 0:
            visit[location] = [1] * N
            for j in range(N):
                visit[j][i] = 1
                for k in range(4):
                    x = location + j * dx[k]
                    y = i + j * dy[k]
                    if 0 <= x < N and 0 <= y < N:
                        visit[x][y] = 1
            n_queen(location + 1, visit)


N = int(input())
cnt = 0
n_queen(0, [[0] * N for _ in range(N)]) # n_queen(location, visited)
print(cnt)