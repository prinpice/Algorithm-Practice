def dfs(check, saved_q, n):
 global count
 if n == N:
  count += 1
  return

 else:
  for j in range(N):
   if check[j] == 0:
    for q in saved_q:
     if abs(n - q[0]) == abs(j - q[1]):
      break
    else:
     check[j] = 1
     dfs(check, saved_q + [[n, j]], n + 1)
     check[j] = 0


N = int(input())
count = 0
dfs([0] * N, [], 0)
print(count)