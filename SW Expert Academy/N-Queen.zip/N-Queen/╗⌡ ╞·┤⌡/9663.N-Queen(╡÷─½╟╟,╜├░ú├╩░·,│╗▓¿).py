from copy import deepcopy
# N = int(input())
N = 8
def Visit(qi,qj,v):
    temp = deepcopy(v)
    cha, hap = qj - qi, qj + qi
    for i in range(N):
        temp[qi][i], temp[i][qj]= 1,1
        if 0<=  i+ cha < N:  temp[i][i + cha] = 1
        if 0<= hap - i < N : temp[hap - i][i] = 1
    return temp

def putQueen(line, visit):
    global cnt
    if line == N :
        cnt += 1
        return
    for j in range(N):
        if visit[line][j] == 0:
            visited = Visit(line, j, visit)
            putQueen(line+1, visited)

cnt = 0
visit = [[0]* N for _ in range(N)]
putQueen(0, visit)
print(cnt)