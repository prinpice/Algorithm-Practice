dx = [1, 1, -1, -1, 1, -1, 0, 0]
dy = [1, -1, -1, 1, 0, 0, 1, -1]


def n_queen(location, visit):
    global N, cnt
    if location == N:
        cnt += 1
        return
    for i in range(N):
        if visit[location][i] == 0:
            for j in range(N):
                for k in range(8):
                    x = location + j * dx[k]
                    y = i + j * dy[k]
                    if 0 <= x < N and 0 <= y < N:
                        visit[x][y] += location + 1
            n_queen(location + 1, visit)
            for j in range(N):
                for k in range(8):
                    x = location + j * dx[k]
                    y = i + j * dy[k]
                    if 0 <= x < N and 0 <= y < N:
                        visit[x][y] -= location + 1


N = int(input())
cnt = 0
n_queen(0, [[0] * N for _ in range(N)])
print(cnt)